package com.apcob.neft.signer;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Signatureflow_JavaCompute {

	public static void getProperties( String propLoc, String pass,String sourcefile,String [] signature) 
	{	
		Properties properties = new Properties();
		try {
			File propFile = new File(propLoc);
			FileInputStream fileInput = new FileInputStream(propFile);
			properties.load(fileInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Neft_Sign n = new Neft_Sign();
		String signed = "";
        String currentLine = "";
        StringBuffer strBuff = null;
        BufferedReader br =null;
 		strBuff = new StringBuffer();

    	try
        { 
        signed  = Neft_Sign.sign(propLoc, pass, sourcefile);
        System.out.println("Signature of the message : "+signed.trim());
        signature[0] = signed;
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
	}

}
